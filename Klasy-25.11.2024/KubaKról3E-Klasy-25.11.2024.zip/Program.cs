﻿using Klasy_25._11._2024.Scripts;
using System;
using System.Collections.Generic;

namespace Klasy_25._11._2024
{
    internal class Program
    {

        static void Main(string[] args)
        {
            Menu.Interfejs();

            Console.ReadKey();
        }
    }
}
